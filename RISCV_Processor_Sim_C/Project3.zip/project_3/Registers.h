#ifndef __REGISTERS_H__
#define __REGISTERS_H__

#define NUM_OF_REGS 64

extern const char* REGISTER_NAME[NUM_OF_REGS];

#endif
